@include('partials._head')
@include('partials._body')
@include('partials._footer')