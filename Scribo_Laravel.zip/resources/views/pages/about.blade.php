@extends('layouts.app')

@section('title', '| About')

@section('content')
<div class="row">
	<div class="col-md-8 offset-md-2">
		<div class="card">
			<div class="card-header">
				Sander Buruma
			</div>
			<div class="card-body">
				<p>Astute fullstack web developer, at your service!</p>
			</div>
		</div>
	</div>
</div>
@endsection