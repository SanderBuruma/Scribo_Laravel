# Scribo Cursim (laravel)

#### A typing game by Sander "Cubit32" Buruma

---

A typing game by Sander Buruma, complete with lots of Catholic texts.

## Installation

clone, run composer update, php artisan migrate -v --seed

## Features

- Texts to type
- Leaderboard
- User Profile
- And More!

## Plugins

- Bootstrap
- Jquer
- Select2