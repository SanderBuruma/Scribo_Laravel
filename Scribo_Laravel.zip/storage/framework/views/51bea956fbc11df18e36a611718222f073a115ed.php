<?php $__env->startSection('title', '| About'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-8 offset-md-2">
		<div class="card">
			<div class="card-header">
				Sander Buruma
			</div>
			<div class="card-body">
				<p>Astute fullstack web developer, at your service!</p>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>